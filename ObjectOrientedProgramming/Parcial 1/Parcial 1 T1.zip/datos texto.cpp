#include<iostream>
#include<string>
using namespace std;

class TEXTO{
	private:
	string str, inv; int nchar, nvocal, ncons, i;	
	int contadorch=0; int contadorv = 0, contadorc=0;
	string newstr;	
	public:
			
		void get_str(){
			cout<<"Ingresa la palabra que analizar: "; cin>>str;
		}
		void num_char(){
			for(i=0;str[i];i++)
			contadorch++;
			cout<<"Numero de caracteres: "<<contadorch<<'\n';
		}
		void voc_cons(){
			
			for( i=0; str[i]; i++){
				if(str[i]=='a'||str[i]=='e'||str[i]=='i'||str[i]=='o'||str[i]=='u'){
					contadorv++;
				}
				else{
					contadorc++;
				}
			}
			cout<<"Vocales: "<<contadorv<<'\n';
			cout<<"Consonantes: "<<contadorc<<'\n';
			}
		void reversa_pal(){
			
			for(int i=str.length()-1; i>=0; i--){
			newstr += str[i];
			}
			cout<<"palabra invertida: "<<newstr;
			bool pali;
			cout<<"\npalindromo: ";
			if(str==newstr){
				pali=true; 	
			}
			if(pali){
					cout<<"si";
				}
				else {cout<<"no";
				}
		}
		
		
		
};

int main(){
	cout<<"ANALIZADOR DE PALABRAS\n";
	TEXTO t1; 
	t1.get_str(); 
	t1.num_char();
	t1.voc_cons();
	t1.reversa_pal();
	
	
}
