#include <iostream>
#include<string>
#include<map>
using namespace std; 


class ROMANOS{
	private:
	 int input_num; string romano;
	string m[4]={"","M","MM","MMM"};
	string c[10]={"","C","CC","CCC","CD","D","DC","DCC","DCCC","CM"};
	string x[10]={"","X","XX","XXX", "XL","L", "LX","LXX","LXXX","XC"};
	string ii[10]={"","I", "II","III","IV","V","VI","VII","VIII","IX"};
	int arabe = 0, i, n;
//	int cdigitos = input_roma.length();
	int base=0;

	int value(char r){
	if (r == 'I')
        return 1;
    if (r == 'V')
        return 5;
    if (r == 'X')
        return 10;
    if (r == 'L')
        return 50;
    if (r == 'C')
        return 100;
    if (r == 'D')
        return 500;
    if (r == 'M')
        return 1000;
        	
	}



	

	
	public:
		void inputdec(){
			cout<<"Ingresa numero decimal:";
			cin>>input_num;
		}
		
		/*void inputrom(string input_roma){
			cout<<"Ingresa numero romano(mayusculas):";
			cin>>p; 
		}*/
		string romanizar(){
			string millar = m[input_num/1000];
			string centena= c[(input_num%1000)/100];
			string decena= x[(input_num%100/10)];
			string unidad = ii[input_num%10];
			romano = millar+centena+decena+unidad;
			cout<<romano;				
		}
	
		 
		void arabizar(string q){
			for(i=q.length()-1;i>=0;i--){
				if(value(q[i])>=base){
					arabe+=value(q[i]);}
					else{
						arabe-=value(q[i]);	
						}
					base=value(q[i]);	
					}
				cout <<arabe; 	
			}
			
		
		
};
int main(){
	cout<<"CONVERTIDOR romano <-> decimal\n";
	cout<<"Ingrese la operacipon que desea relizar\n";
	cout<<"1. romano a decimal\n2. decimal a romano\n"; 
	int answ; cin>>answ;
	if(answ==1){
		ROMANOS dec;
		dec.inputdec();
		dec.romanizar();
	}
	else if (answ==2){
		cout<<"Numero romano (mayusculas): ";
		string s; cin>>s;
		ROMANOS rom;
		rom.arabizar(s);
		
	}
	else cout<<"Respuesta no valida";
	

	return 0;
	
}
