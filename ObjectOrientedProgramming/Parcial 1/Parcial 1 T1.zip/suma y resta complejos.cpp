#include<iostream>
using namespace std;
class COMPLEJO{
	int real1, im1, real2, im2; 
	int sumareal, sumaim, restareal, restaim;
	public:
		
		void input_num(){
			cout<<"Numero complejo (a+bi) \n"; 
			cout<<"Parte real a: "; cin>>real1;
			cout<<"Parte imaginaria bi: ";cin>>im1;
			cout<<"Numero complejo (c+di)\n"; 
			cout<<"Parte real c: "; cin>>real2; 
			cout<<"Parte imaginaria di: "; cin>>im2;
		} 
		void sumayresta(){
			sumareal=real1+real1; sumaim=im1+im2;
			restareal=real1-real2; restaim=im1-im2;
			cout<<"Suma: ("<<sumareal<<" + "<<sumaim<<"i)";
			cout<<"\nResta: (("<<restareal<<") + ("<<restaim<<"i))";
		}
};

int main(void){
	cout<<"SUMA Y RESTA DE NUMEROS COMPLEJOS\n";
	COMPLEJO a1;
	a1.input_num();
	a1.sumayresta();
	
}
