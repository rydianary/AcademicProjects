#include<iostream>
#include<string>
#include<math.h>
using namespace std;

class CUADRADO {
	private: 
	float lado, perimetro, area, diagonal;
	public:
		
		void input(){
			cout<<"Ingresa la magnitud del lado del cuadrado: ";
			cin>>lado;
		}
		void clado(){
			 cout<<"Lado 1: "<<lado<<'\n';
			 cout<<"Lado 2: "<<lado<<'\n';
			 cout<<"Lado 3: "<<lado<<'\n';
			 cout<<"Lado 4: "<<lado<<'\n';
		}
		void cperimetro(){
			perimetro=lado*4;
			cout<<"Perimetro: "<<perimetro<<'\n';
		}
		void carea(){
			area=lado*lado;
			cout<<"Area: "<<area<<'\n';
		}
		void cdiagonal(){
			diagonal=sqrt(2*lado*lado);
			cout<<"Diagonal: "<<diagonal;
		}
					
};

int main(void){
	cout<<"Datos de cuadrados\n";
	CUADRADO obj1; 
	obj1.input();
	obj1.clado();
	obj1.cperimetro();
	obj1.carea();
	obj1.cdiagonal();
	return 0; 
}
