#include<iostream>
//C� <-> �F
int main(){
	std::cout<<"CONVERSOR �F - �C\n"; 
	std::cout<<"Ingrese: \n1 para �F a �C\n2 para �C a �F\n";
	int opcn; std::cin>>opcn; int grad;
	switch(opcn){
		case 1: {
			std::cout<<"Fahrenheit: "; std::cin>>grad;
			std::cout<<"Celsius: "<<(grad-32)/1.8;
			break;
		}
		case 2:{
			std::cout<<"Celsius: "; std::cin>>grad;
			std::cout<<"Fahrenheit: "<<1.8*grad+32;
			break;
		}
		default: {
			std::cout<<"opcion no valida";
			break;
		}
	}
	return 0;
}
