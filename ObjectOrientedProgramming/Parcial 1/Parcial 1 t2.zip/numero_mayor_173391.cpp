#include<iostream>
//Encuentra el numero mayor dado 5 numeros
using namespace std; 
int main(){
	cout<<"Encuentra el numero mayor!\n";
	int n=5;int arr[n]; int danumber=0;
	cout<<"Ingresa 5 numeros: "; 
	for(int i=0; i<n; i++){
		cin>>arr[i];
		if(arr[i]>danumber){
			danumber=arr[i];
		}
	}

	cout<<"El numero mayor es: "<< danumber; 
}

