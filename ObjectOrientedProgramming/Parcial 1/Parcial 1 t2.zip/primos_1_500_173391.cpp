#include <iostream>
using namespace std;
int main(){
	//Numeros primos entre 1 y 500
	cout<<"Numeros primos entre 1 y 500: \n";
	int factor=0;
	for(int i=2; i<=500;i++){	
		for( int j=1;j<=i;j++){
			if(i%j==0){
			factor++;	
		}	
	}
	if (factor==2){
		cout<<i<<" "; 
	}
	factor=0;
	}}

	
	
		


