#include <iostream>
//suma impares 1 - 1500
using namespace std;
int main(){
	int suma=0;
	for(int i=1;i<=1500;i++){
		if(i%2==0){
			continue; 
		}
		else{
			suma+=i;
		}
	}
	cout<<"La suma de los impares del 1 a 1500 es: "<<suma;
}
