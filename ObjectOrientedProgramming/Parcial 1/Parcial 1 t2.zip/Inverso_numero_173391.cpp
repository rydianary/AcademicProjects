#include<iostream>
#include<bits/stdc++.h>
using namespace std; 
//INVERSO DE UN NUMERO
int main(){
	cout<<"Ingresa el numero a invertir: ";
	string num; 
	cin>> num; 
	reverse(num.begin(), num.end());
	cout<<num; 
	return 0; 
	
}

